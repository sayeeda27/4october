<div class="feature-area pt-30 pb-30 hide">
 <div class="container">
   <div class="row">
      <div class="col-xl-6">
         <div class="feature-text">
           <h3>We are here to aware you about your child immune system. </h3>
           <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
           Vel mollitia ipsum quis cumque quos sunt voluptates non, quaerat accusamus ipsam tenetur iste voluptatum reprehenderit et consequatur magni saepe nam? Nostrum?</p>
           <a href="#" class="btn">Read more</a>
         </div>
      </div>
      <div class="col-xl-6">
        <div class="feature-img">
         <img src="<?php echo base_url();?>assets/img/kid.jpg" alt="feature_img">
        </div>
      </div>
   </div>
 </div>
</div>