<div class="alert-area text-center feature-area">
    <div class="container">
        <div class="alert-form">
          <form>
            <div class="form-group">
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Date of Birth">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Vaccine Name">
            </div>
            <button type="submit" class="btn">Send Alert</button>
            </form>
        </div>
    </div>
</div>